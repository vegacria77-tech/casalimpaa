# Design Guidelines for Organiza Lar Landing Page

## Design Approach
**Reference-Based Approach**: Drawing inspiration from successful home organization and lifestyle brands like The Home Edit, Marie Kondo's KonMari, and modern wellness platforms. The design emphasizes trust, transformation, and feminine appeal while maintaining professional credibility.

## Core Design Elements

### Color Palette
- **Background**: Pure white (#FFFFFF) for clean, organized feel
- **Headings**: Charcoal (#1C1C1C) for strong hierarchy
- **Body Text**: Medium gray (#3A3A3A) for readability
- **Primary CTA**: Fresh green (#1FA36A) suggesting growth and organization
- **CTA Hover**: Deeper green (#16885A) for interaction feedback
- **Accent**: Soft pink or warm beige touches for feminine appeal

### Typography
- **Primary Font**: System fonts (Arial, Helvetica) or single Google Font (Inter/Open Sans)
- **Minimum Text Size**: 16px for accessibility
- **Heading Hierarchy**: h1 (32px), h2 (28px), h3 (24px) with proper semantic structure
- **Button Text**: 600 font-weight for emphasis

### Layout System
- **Container**: Single column, max-width 640px, centered
- **Spacing**: Consistent 16px, 24px, 32px units for padding/margins
- **Border Radius**: 12px for buttons, 16px for cards/sections
- **Shadows**: Subtle box-shadow for depth without distraction

### Component Library
- **CTAs**: Full-width mobile buttons, 14-16px padding, prominent green
- **Trust Seals**: Flexible grid below CTAs (2-3 columns, 28-40% width each)
- **Image Containers**: Responsive with proper aspect ratios
- **FAQ Section**: Clean accordion-style or simple list format
- **Cards**: Subtle shadows, rounded corners, generous whitespace

## Content Strategy
- **Hero Focus**: Immediate value proposition with emotional connection
- **Trust Building**: Social proof and guarantees prominently featured
- **Transformation Story**: Before/after narrative throughout sections
- **Risk Reversal**: Strong guarantee and security messaging

## Images
**Hero Image**: Medium-sized image of smiling woman in organized living space positioned below main headline
**Supporting Images**: Smaller contextual images below each section title showing:
- Exhausted woman with shopping bags (identification section)
- Product mockups (digital files)
- Before/after room transformations
- Happy families in organized spaces
- Creator portrait (Juliana Martins)
**Trust Seals**: Flexible grid of security/guarantee badges below every CTA

## Accessibility & Performance
- **Contrast**: AA compliance for all text
- **Focus States**: Visible keyboard navigation
- **Lazy Loading**: All images below fold
- **Semantic HTML**: Proper heading hierarchy and ARIA labels
- **Mobile-First**: Optimized for touch interaction and small screens

## Visual Hierarchy
Strong contrast between sections using whitespace, typography scale, and strategic color placement. Green CTAs act as visual anchors throughout the scroll experience, with trust elements reinforcing credibility at every decision point.